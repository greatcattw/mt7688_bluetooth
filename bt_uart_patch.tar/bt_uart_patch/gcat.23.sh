#/bin/sh
opkg install ipk.23/bluez-libs_5.30-1_ramips_24kec.ipk

opkg install ipk.23/libattr_20150220-1_ramips_24kec.ipk
opkg install ipk.23/libical_1.0-1_ramips_24kec.ipk
opkg install ipk.23/libdbus_1.9.14-1_ramips_24kec.ipk
opkg install ipk.23/dbus_1.9.14-1_ramips_24kec.ipk
opkg install ipk.23/glib2_2.43.4-1_ramips_24kec.ipk
opkg install ipk.23/bluez-utils_5.30-1_ramips_24kec.ipk


opkg install ipk.23/kmod-lib-crc16_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-crypto-core_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-crypto-aead_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-crypto-pcompress_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-crypto-hash_3.18.23-1_ramips_24kec.ipk

opkg install ipk.23/kmod-crypto-manager_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-crypto-ecb_3.18.23-1_ramips_24kec.ipk

opkg install ipk.23/kmod-input-evdev_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-hid_3.18.23-1_ramips_24kec.ipk
opkg install ipk.23/kmod-bluetooth_3.18.23-1_ramips_24kec.ipk

opkg install ipk.23/picocom_1.7-1_ramips_24kec.ipk
cp conf/system.conf /etc/dbus-1/system.conf
